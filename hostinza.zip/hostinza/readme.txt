/**
 * Theme Name: hostinza
 * Theme URI: http://www.xpeedstudio.com
 * Description: Hostinza is powerful and modern multipurpose responsive WordPress Theme.
 * Version: 2.9
 * Author: XpeedStudio
 * Author URI: http://www.xpeedstudio.com
 * License: GNU General Public License version 3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 * Tags: one-column, two-columns, right-sidebar, left-sidebar, custom-menu, featured-images, post-formats, sticky-post, translation-ready
 * Text Domain: hostinza;
 *
 * XS
 */


/*
 * Chagne log

* Version: 2.9  (2021-04-07)
* Fix: Elementor old repeater upgrade to new repeater issue fixed
* Fix: Responsive and CSS issue fixed 


2.8 1-17-2021

* Update revslider version (6.3.5)
* Domain checker color picker issue solved
* Responsive and CSS issue fixed
* File missing issue fixed
* Change remote server

2.6 - 2020-11-29
 * Removed Google plus and add Youtube on hostinza Widgets
 * Update socail media option
/*